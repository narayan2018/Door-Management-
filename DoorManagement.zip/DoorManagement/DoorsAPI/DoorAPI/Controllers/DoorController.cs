﻿using DoorAPI.Models;
using Everbridge.ControlCenter.TechnicalChallenge.DoorDatabase;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace DoorAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class DoorController : ControllerBase
    {
        private readonly ILogger<DoorController> _logger;
        private readonly DoorRepositoryService _doorRepositoryService;

        public DoorController(ILogger<DoorController> logger, DoorRepositoryDatabaseContext databaseContext)
        {
            _logger = logger;
            _doorRepositoryService = new DoorRepositoryService(databaseContext);
        }

        [HttpGet]
        public async Task<IEnumerable<string>> Get()
        {
            await Task.Delay(300);
            return _doorRepositoryService.GetDoorsIds();
        }

        [HttpGet("GetAll")]
        public async Task<IEnumerable<DoorRecord>> GetAll()
        {
            return await _doorRepositoryService.GetAllDoors();
        }

        [HttpGet]
        [Route("{doorId}")]
        public async Task<DoorModel> GetDoorById([FromRoute][Required] string doorId)
        {
            var doorRecord = await _doorRepositoryService.GetDoor(doorId);

            return (doorRecord == null)
                ? null
                : new DoorModel
                {
                    Id = doorRecord.Id,
                    Label = doorRecord.Label,
                    IsOpen = doorRecord.IsOpen,
                    IsLocked = doorRecord.IsLocked
                };
        }

        [HttpPost("AddDoor")]
        public async Task<DoorRecordDto> AddDoor([FromBody] DoorRecord user)
        {
            var dtoDoor = new DoorRecordDto(user);
            var doorRecord = await _doorRepositoryService.AddDoor(dtoDoor);

            return doorRecord;
        }

        [HttpDelete("Delete/{id}")]
        public async Task<DoorRecordDto> DeleteDoor(string Id)
        {
            
            var doorRecord = await _doorRepositoryService.RemoveDoor(Id);
            return doorRecord;
        }

        [HttpPut("Update")]
        public async Task<DoorRecordDto> UpdateDoor([FromBody] DoorRecord door)
        {
            dynamic doorRecord=null;
            if (!string.IsNullOrEmpty(door.Id))
            {
                 doorRecord = await _doorRepositoryService.UpdateDoor(door);
            }
            
            return doorRecord;
        }
    }
}
