﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Everbridge.ControlCenter.TechnicalChallenge.DoorDatabase
{
    public class DoorRepositoryService
    {
        private readonly DoorRepositoryDatabaseContext _userRepositoryDatabaseContext;

        public DoorRepositoryService(DoorRepositoryDatabaseContext userRepositoryDatabaseContext)
        {
            _userRepositoryDatabaseContext = userRepositoryDatabaseContext;
        }

        public List<string> GetDoorsIds()
        {
            return _userRepositoryDatabaseContext.Doors.Select(x => x.Id).ToList();
        }

        public async Task<IEnumerable<DoorRecord>> GetAllDoors()
        {
            return await _userRepositoryDatabaseContext.Doors.ToListAsync();
        }

        public async Task<DoorRecordDto> GetDoor(string doorId)
        {
            var user = await _userRepositoryDatabaseContext.Doors.FindAsync(doorId);
            return (user != null) ? new DoorRecordDto(user) : null;
        }

        public async Task<DoorRecordDto> AddDoor(DoorRecordDto door)
        {
            var record = new DoorRecord
            {
                FacilityId=door.FacilityId,
                Label = door.Label,
                IsLocked = door.IsLocked,
                IsOpen = door.IsOpen
            };
            await _userRepositoryDatabaseContext.Doors.AddAsync(record);
            await _userRepositoryDatabaseContext.SaveChangesAsync();
            return new DoorRecordDto(record);
        }

        public async Task<DoorRecordDto> RemoveDoor(string doorId)
        {
            var record = await _userRepositoryDatabaseContext.Doors.FindAsync(doorId);
            if (record == null)
            {
                return null;
            }

            _userRepositoryDatabaseContext.Remove(record);
            await _userRepositoryDatabaseContext.SaveChangesAsync();

            return new DoorRecordDto(record);
        }

        public async Task<DoorRecordDto> UpdateDoor(DoorRecord door)
        {
            try
            {
                _userRepositoryDatabaseContext.Entry(door).State = EntityState.Modified;
                await _userRepositoryDatabaseContext.SaveChangesAsync();

                var user = await _userRepositoryDatabaseContext.Doors.FindAsync(door.Id);
                return (user != null) ? new DoorRecordDto(user) : null;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
