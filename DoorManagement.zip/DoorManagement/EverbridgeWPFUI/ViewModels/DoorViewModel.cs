﻿using EverbridgeWPFUI.Command;
using EverbridgeWPFUI.Models;
using EverbridgeWPFUI.ServiceLayer;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;

namespace EverbridgeWPFUI.ViewModels
{
    public class DoorViewModel: ViewModelBase
    {
        private const string MessageBoxText = "The door has been deleted successfully.";
       // private APICall _dbAccess = null;
        public List<string> FacilityList { get; set; }
        private readonly IServiceCall _service = null;

        /// <summary>
        /// Default
        /// </summary>
        public DoorViewModel()
        {
            _service = new ServiceCall();
            _doors = _service.GetAllDoors();
            _doorDetails = new DoorModel();
            FacilityList = GetFacility();
            Message = string.Empty;
        }

        private List<string> GetFacility()
        {
            var facilityList = new List<string>() { "100", "101", "102", "104" };

            return facilityList;
        }

        /// <summary>
        /// Door save SaveDoorCommand
        /// </summary>
        private DelegateCommand _saveDoorCommand;
        public DelegateCommand SaveDoorCommand
        {
            get
            {
                _saveDoorCommand = _saveDoorCommand ?? new DelegateCommand(SaveDoors);
                return _saveDoorCommand;
            }
        }

        /// <summary>
        /// Update Door Command
        /// </summary>
        private DelegateCommand _updateDoorCommand;
        public DelegateCommand UpdateDoorCommand
        {
            get
            {
                _updateDoorCommand = _updateDoorCommand ?? new DelegateCommand(UpdateDoor);
                return _updateDoorCommand;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private DelegateCommand _deleteDoorCommand;
        public DelegateCommand DeleteDoorCommand
        {
            get
            {
                return _deleteDoorCommand = _deleteDoorCommand ?? new DelegateCommand(DeleteDoor);
            }
        }

        private ObservableCollection<DoorModel> _doors;
        public ObservableCollection<DoorModel> Doors
        {
            get
            {
                return _doors;
            }
            set
            {
                _doors = value;
                OnPropertyChanged("Doors");
            }
        }

        private string _selectedFacility;
        public string SelectedFacility
        {
            get { return _selectedFacility; }
            set
            {
                _selectedFacility = value;
            }
        }


        private DoorModel _doorDetails;
        public DoorModel DoorDetails
        {
            get
            {
               return  _doorDetails;
            }
            set
            {
                _doorDetails = value;
                OnPropertyChanged("DoorDetails");
            }
        }
        /// <summary>
        /// 
        /// </summary>
        private DoorModel _selectedDoor;
        public DoorModel SelectedDoor
        {
            get { return _selectedDoor; }
            set
            {
                _selectedDoor = value;
            }
        }

        private string _message;
        public string Message
        {
            get
            {
                return _message;
            }
            set
            {
                _message = value;
                OnPropertyChanged("Message");
            }
        }


        /// <summary>
        /// Update
        /// </summary>
        private void UpdateDoor()
        {
            if (SelectedDoor != null)
            {
                var updateDoor = new DoorModel()
                {
                    Id = SelectedDoor.Id,
                    FacilityId = SelectedDoor.FacilityId,
                    Label = SelectedDoor.Label,
                    IsLocked = SelectedDoor.IsLocked,
                    IsOpen = SelectedDoor.IsOpen
                };
              bool IsUpdated= _service.UpdateDoor(updateDoor);

                if(IsUpdated)
                {
                    Doors = _service.GetAllDoors();
                    OnPropertyChanged("Doors");
                }
                    MessageBox.Show("The door has been updated successfully.", "Update Door", MessageBoxButton.OK, MessageBoxImage.Information);
            }else
            {
                MessageBox.Show("Please select the door for updated.", "Update Door", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            
        }
        /// <summary>
        /// Add Door
        /// </summary>
        private void SaveDoors()
        {
            Message = string.Empty;
            bool IsCreated = false;



            if (DoorDetails != null && !string.IsNullOrEmpty(SelectedFacility) && !string.IsNullOrEmpty(DoorDetails.Label))
            {
                var addRecord = new DoorModel()
                {
                    Id = DoorDetails.Id,
                    Label= DoorDetails.Label,
                    FacilityId = Convert.ToInt32(SelectedFacility),
                    IsOpen = DoorDetails.IsOpen,
                    IsLocked = DoorDetails.IsLocked
                };

               
                try
                {
                     IsCreated = _service.AddDoor(addRecord);
                    if(IsCreated)
                    {
                        Doors = _service.GetAllDoors();
                        OnPropertyChanged("Doors");
                    }
                }
                catch (Exception){ throw; }

                Message = IsCreated ? "Door added sucessfully!" : "Unable to add the door, please try again!";
            }        
        }

        private void DeleteDoor()
        {
            if(SelectedDoor!=null && !string.IsNullOrEmpty(SelectedDoor.Id))
            {
                string id = SelectedDoor.Id;
                bool IsDeleted = _service.DeleteDoor(id);

                if(IsDeleted)
                {
                    Doors = _service.GetAllDoors();
                    OnPropertyChanged("Doors");
                    MessageBox.Show(MessageBoxText, "Delete Door", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                  
            }else
            {
                MessageBox.Show("Please select the door for delete.", "Delete Door", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

    }
}
