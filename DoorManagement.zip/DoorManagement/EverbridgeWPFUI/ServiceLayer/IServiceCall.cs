﻿using EverbridgeWPFUI.Models;
using System.Collections.ObjectModel;

namespace EverbridgeWPFUI.ServiceLayer
{
    interface IServiceCall
    {
        ObservableCollection<DoorModel> GetAllDoors();
        bool AddDoor(DoorModel door);
        bool UpdateDoor(DoorModel door);
        bool DeleteDoor(string Id);
    }
}
