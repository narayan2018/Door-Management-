﻿using EverbridgeWPFUI.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Net.Http;


namespace EverbridgeWPFUI.ServiceLayer
{
    public class ServiceCall: IServiceCall
    {

        //private static ObservableCollection<DoorModel> doors { get; set; }

        private string getAPI = string.Empty;
        private string addAPI = string.Empty;
        private string deleteAPI = string.Empty;
        private string updaetAPI = string.Empty;
        public ServiceCall()
        {
            getAPI = ConfigurationManager.AppSettings["GetAPI"];
            addAPI = ConfigurationManager.AppSettings["AddAPI"];
            deleteAPI = ConfigurationManager.AppSettings["DeleteAPI"];
            updaetAPI = ConfigurationManager.AppSettings["UpdateAPI"];

            //    doors = new ObservableCollection<DoorModel>();
            //    doors.Add(new DoorModel { Id = "1", Label = "Left", IsLocked = true, IsOpen = false });
            //    doors.Add(new DoorModel { Id = "2", Label = "Left", IsLocked = true, IsOpen = false });
            //    doors.Add(new DoorModel { Id = "3", Label = "Left", IsLocked = true, IsOpen = false });
            //    doors.Add(new DoorModel { Id = "4", Label = "Left", IsLocked = true, IsOpen = false });
        }

        /// <summary>
        /// GetAllDoors
        /// </summary>
        /// <returns></returns>
        public ObservableCollection<DoorModel> GetAllDoors()
        {
            var doors = new ObservableCollection<DoorModel>();
            // string url = "http://localhost:46188/api/Door/GetAll";
            try
            {
                List<DoorModel> records = null;
                using (var client = new HttpClient())
                {
                    var response = client.GetAsync(getAPI).GetAwaiter().GetResult();
                    if (response.IsSuccessStatusCode)
                    {
                        var department = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();

                        records = JsonConvert.DeserializeObject<List<DoorModel>>(department);
                    }
                    else
                    {
                        Console.WriteLine("Internal server Error");
                    }
                }

                records.ForEach(x => doors.Add(new DoorModel
                {
                    Id = x.Id,
                    FacilityId = x.FacilityId,
                    Label = x.Label,
                    IsLocked = x.IsLocked,
                    IsOpen = x.IsOpen
                }));

            }
            catch (Exception ex)
            {
                throw;
            }

            return doors;
        }

        /// <summary>
        /// Add Record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public bool AddDoor(DoorModel door)
        {
            string jsonPlayLoad = JsonConvert.SerializeObject(door, Formatting.Indented);

            try
            {
                // string url = "http://localhost:46188/api/Door/AddDoor";

                using (var client = new HttpClient())
                {
                    using (var content = new StringContent(jsonPlayLoad, System.Text.Encoding.UTF8, "application/json"))
                    {
                        HttpResponseMessage result = client.PostAsync(addAPI, content).GetAwaiter().GetResult();
                        if (result.StatusCode == System.Net.HttpStatusCode.OK)
                            return true;
                        string returnValue = result.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            return false;
        }

        /// <summary>
        /// UpdateDoor
        /// </summary>
        /// <param name="door"></param>
        /// <returns></returns>
        public bool UpdateDoor(DoorModel door)
        {
            string jsonPlayLoad = JsonConvert.SerializeObject(door, Formatting.Indented);

            try
            {
                //string url = "http://localhost:46188/api/Door/Update";

                using (var client = new HttpClient())
                {
                    using (var content = new StringContent(jsonPlayLoad, System.Text.Encoding.UTF8, "application/json"))
                    {
                        HttpResponseMessage result = client.PutAsync(updaetAPI, content).GetAwaiter().GetResult();
                        if (result.StatusCode == System.Net.HttpStatusCode.OK)
                            return true;
                        string returnValue = result.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            return true;
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public bool DeleteDoor(string Id)
        {
            //string url = "http://localhost:46188/api/Door/Delete/" + Id;
            string url = deleteAPI + Id;

            try
            {
                using (var client = new HttpClient())
                {
                    var response = client.DeleteAsync(url).GetAwaiter().GetResult();
                    if (response.IsSuccessStatusCode)
                    {
                        var department = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();

                        var records = JsonConvert.DeserializeObject<DoorModel>(department);
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }


            return true;
        }
    }
}
