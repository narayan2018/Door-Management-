﻿namespace EverbridgeWPFUI.Models
{
    public class DoorModel
    {     
        public string Id { get; set; }
        public int FacilityId { get; set; }
        public string Label { get; set; }
 
        public bool IsOpen { get; set; }

        public bool IsLocked { get; set; }

    }
}
