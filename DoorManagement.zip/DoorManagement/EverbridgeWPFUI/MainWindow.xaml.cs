﻿using System.Windows;

namespace EverbridgeWPFUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //var doorvm = new DoorViewModel();
            //this.DataContext = doorvm;
        }
    }
}
